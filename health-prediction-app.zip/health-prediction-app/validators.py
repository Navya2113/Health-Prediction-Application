"""
validators.py
-------------
Basic input validation for patient records.
"""

import re
from datetime import date, datetime

EMAIL_REGEX = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def validate_full_name(name):
    if not name or not name.strip():
        return "Full name is required."
    if len(name.strip()) < 2:
        return "Full name must be at least 2 characters."
    return None


def validate_email(email):
    if not email or not email.strip():
        return "Email is required."
    if not EMAIL_REGEX.match(email.strip()):
        return "Email address format is invalid."
    return None


def validate_dob(dob_value):
    if not dob_value:
        return "Date of birth is required."
    if isinstance(dob_value, str):
        try:
            dob_value = datetime.strptime(dob_value, "%Y-%m-%d").date()
        except ValueError:
            return "Date of birth must be a valid date (YYYY-MM-DD)."
    if dob_value > date.today():
        return "Date of birth cannot be in the future."
    return None


def validate_numeric(value, field_name, min_value=0, max_value=2000):
    if value is None:
        return f"{field_name} is required."
    try:
        num = float(value)
    except (TypeError, ValueError):
        return f"{field_name} must be a numeric value."
    if num < min_value or num > max_value:
        return f"{field_name} must be between {min_value} and {max_value}."
    return None


def validate_patient_form(full_name, dob, email, glucose, haemoglobin, cholesterol):
    """Run all validations and return a list of error messages (empty if valid)."""
    errors = []
    for err in [
        validate_full_name(full_name),
        validate_email(email),
        validate_dob(dob),
        validate_numeric(glucose, "Glucose", 0, 1000),
        validate_numeric(haemoglobin, "Haemoglobin", 0, 30),
        validate_numeric(cholesterol, "Cholesterol", 0, 1000),
    ]:
        if err:
            errors.append(err)
    return errors
