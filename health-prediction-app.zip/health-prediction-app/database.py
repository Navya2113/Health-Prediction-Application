"""
database.py
------------
Handles all persistent storage (SQLite) for patient records.
Provides simple CRUD functions used by the Streamlit app.
"""

import sqlite3
from contextlib import contextmanager

DB_PATH = "patients.db"


@contextmanager
def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    """Create the patients table if it doesn't already exist."""
    with get_connection() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS patients (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                full_name TEXT NOT NULL,
                dob TEXT NOT NULL,
                email TEXT NOT NULL,
                glucose REAL NOT NULL,
                haemoglobin REAL NOT NULL,
                cholesterol REAL NOT NULL,
                remarks TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
            """
        )


def create_patient(full_name, dob, email, glucose, haemoglobin, cholesterol, remarks):
    with get_connection() as conn:
        cur = conn.execute(
            """
            INSERT INTO patients (full_name, dob, email, glucose, haemoglobin, cholesterol, remarks)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (full_name, dob, email, glucose, haemoglobin, cholesterol, remarks),
        )
        return cur.lastrowid


def get_all_patients():
    with get_connection() as conn:
        rows = conn.execute("SELECT * FROM patients ORDER BY id DESC").fetchall()
        return [dict(r) for r in rows]


def get_patient(patient_id):
    with get_connection() as conn:
        row = conn.execute("SELECT * FROM patients WHERE id = ?", (patient_id,)).fetchone()
        return dict(row) if row else None


def update_patient(patient_id, full_name, dob, email, glucose, haemoglobin, cholesterol, remarks):
    with get_connection() as conn:
        conn.execute(
            """
            UPDATE patients
            SET full_name = ?, dob = ?, email = ?, glucose = ?, haemoglobin = ?,
                cholesterol = ?, remarks = ?
            WHERE id = ?
            """,
            (full_name, dob, email, glucose, haemoglobin, cholesterol, remarks, patient_id),
        )


def delete_patient(patient_id):
    with get_connection() as conn:
        conn.execute("DELETE FROM patients WHERE id = ?", (patient_id,))
