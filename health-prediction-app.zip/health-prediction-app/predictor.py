"""
predictor.py
------------
AI/ML prediction module for the Health Prediction Application.

Two prediction paths are supported (as allowed by the task brief, which
permits "any suitable public API, Health API, AI service, ML service or
custom ML model"):

1. EXTERNAL API (optional) - if HEALTH_API_URL / HEALTH_API_KEY are set as
   environment variables, the app will call that external service to get a
   prediction. This keeps secrets out of source control (read from env vars,
   never hard-coded).

2. CUSTOM ML MODEL (default / fallback) - a scikit-learn RandomForest
   classifier trained on synthetic-but-clinically-plausible data, mapping
   Glucose / Haemoglobin / Cholesterol to a risk category. This makes the
   app fully runnable out-of-the-box with no external account/API key
   required, while still satisfying the "AI/ML module" requirement.

The model is trained once and cached to disk (model.joblib) the first time
the app runs.
"""

import os
import json
import numpy as np
import pandas as pd
from joblib import dump, load
from sklearn.ensemble import RandomForestClassifier

MODEL_PATH = "model.joblib"

# Reference ranges used both for synthetic data generation and for
# explaining predictions to the user.
RANGES = {
    "glucose": {"low": 70, "normal_high": 99, "high": 125},          # mg/dL (fasting)
    "haemoglobin": {"low": 12.0, "normal_high": 16.5},                 # g/dL
    "cholesterol": {"normal_high": 200, "high": 240},                  # mg/dL
}


def _label_row(glucose, haemoglobin, cholesterol):
    """Rule-based labeling function used ONLY to generate synthetic
    training data (ground truth) for the ML model below."""
    score = 0
    if glucose >= RANGES["glucose"]["high"]:
        score += 2
    elif glucose > RANGES["glucose"]["normal_high"]:
        score += 1

    if cholesterol >= RANGES["cholesterol"]["high"]:
        score += 2
    elif cholesterol > RANGES["cholesterol"]["normal_high"]:
        score += 1

    if haemoglobin < RANGES["haemoglobin"]["low"]:
        score += 1

    if score >= 3:
        return "High Risk"
    elif score >= 1:
        return "Moderate Risk"
    return "Low Risk"


def _generate_synthetic_dataset(n=4000, seed=42):
    rng = np.random.default_rng(seed)
    glucose = rng.normal(100, 30, n).clip(50, 400)
    haemoglobin = rng.normal(14, 2.5, n).clip(5, 20)
    cholesterol = rng.normal(190, 45, n).clip(100, 400)

    labels = [
        _label_row(g, h, c) for g, h, c in zip(glucose, haemoglobin, cholesterol)
    ]

    return pd.DataFrame(
        {
            "glucose": glucose,
            "haemoglobin": haemoglobin,
            "cholesterol": cholesterol,
            "label": labels,
        }
    )


def train_and_save_model():
    df = _generate_synthetic_dataset()
    X = df[["glucose", "haemoglobin", "cholesterol"]]
    y = df["label"]

    clf = RandomForestClassifier(n_estimators=150, max_depth=6, random_state=42)
    clf.fit(X, y)
    dump(clf, MODEL_PATH)
    return clf


def _load_model():
    if os.path.exists(MODEL_PATH):
        return load(MODEL_PATH)
    return train_and_save_model()


def _explain(glucose, haemoglobin, cholesterol):
    notes = []
    if glucose >= RANGES["glucose"]["high"]:
        notes.append("elevated glucose")
    elif glucose > RANGES["glucose"]["normal_high"]:
        notes.append("borderline glucose")

    if cholesterol >= RANGES["cholesterol"]["high"]:
        notes.append("high cholesterol")
    elif cholesterol > RANGES["cholesterol"]["normal_high"]:
        notes.append("borderline cholesterol")

    if haemoglobin < RANGES["haemoglobin"]["low"]:
        notes.append("low haemoglobin (possible anaemia)")

    return ", ".join(notes) if notes else "all values within normal range"


def predict_via_external_api(glucose, haemoglobin, cholesterol):
    """Optional path: call an external Health/AI API if configured via
    environment variables. Returns None if not configured or on failure,
    so the caller can fall back to the local ML model.

    NOTE: No keys are hard-coded here. Set these as environment variables
    (e.g. in a .env file that is NOT committed to GitHub):
        HEALTH_API_URL
        HEALTH_API_KEY
    """
    api_url = os.environ.get("HEALTH_API_URL")
    api_key = os.environ.get("HEALTH_API_KEY")
    if not api_url:
        return None

    try:
        import requests

        headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}
        payload = {
            "glucose": glucose,
            "haemoglobin": haemoglobin,
            "cholesterol": cholesterol,
        }
        resp = requests.post(api_url, json=payload, headers=headers, timeout=5)
        resp.raise_for_status()
        data = resp.json()
        # Expecting the external API to return something like {"remarks": "..."}
        return data.get("remarks") or json.dumps(data)
    except Exception:
        return None


def predict_health_risk(glucose, haemoglobin, cholesterol):
    """Main entry point used by the app. Tries the external API first
    (if configured), otherwise falls back to the local custom ML model.
    Returns a human-readable remarks string.
    """
    external_result = predict_via_external_api(glucose, haemoglobin, cholesterol)
    if external_result:
        return f"[External API] {external_result}"

    model = _load_model()
    X = pd.DataFrame(
        [[glucose, haemoglobin, cholesterol]],
        columns=["glucose", "haemoglobin", "cholesterol"],
    )
    risk = model.predict(X)[0]
    proba = max(model.predict_proba(X)[0]) * 100
    explanation = _explain(glucose, haemoglobin, cholesterol)

    return f"{risk} ({proba:.0f}% confidence) — {explanation}."
