# Health Prediction Application

A simple health-record management application that stores patient blood test
results and uses an AI/ML model to generate a risk "Remarks" field.

Built as a solution to **Task 1: Evaluation of AI/ML Skills** (Health Prediction
Application using patient blood test results and an external AI/ML Health API).

## Tech Stack

- **Backend:** Python
- **Frontend:** Streamlit (chosen for a clean, fast-to-build, fully interactive
  UI without writing separate HTML/CSS/JS — keeps the focus on the Python/AI
  logic while still giving a polished interface)
- **Storage:** SQLite (file-based, persistent, zero setup)
- **AI/ML:** scikit-learn `RandomForestClassifier`, trained on synthetic but
  clinically-plausible data (see `predictor.py`). The app also supports
  calling an external Health/AI API if one is configured via environment
  variables, with automatic fallback to the local model.

## Features

- **Create / Read / Update / Delete** patient records
- **Input validation:** valid email format, date of birth cannot be in the
  future, blood test values must be numeric and within plausible ranges
- **Persistent storage** via SQLite (`patients.db`, auto-created on first run)
- **AI-generated Remarks:** on save/update, the app predicts a risk category
  (Low / Moderate / High Risk) with a confidence score and a short
  explanation, and stores it in the Remarks field

## Project Structure

```
health-prediction-app/
├── app.py            # Streamlit UI (CRUD screens)
├── database.py        # SQLite persistence layer
├── validators.py       # Input validation logic
├── predictor.py        # ML model + optional external API integration
├── requirements.txt
├── .env.example        # Template for optional external API config (no real keys)
└── .gitignore
```

## Setup & Run

```bash
# 1. Clone the repo
git clone <repo-url>
cd health-prediction-app

# 2. (Recommended) create a virtual environment
python -m venv venv
source venv/bin/activate    # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. (Optional) configure an external Health/AI API
cp .env.example .env
# then edit .env and set HEALTH_API_URL / HEALTH_API_KEY if you have one

# 5. Run the app
streamlit run app.py
```

The app will open at `http://localhost:8501`. The ML model is trained
automatically on first run and cached to `model.joblib`.

## How the AI/ML prediction works

1. If `HEALTH_API_URL` (and optionally `HEALTH_API_KEY`) are set as
   environment variables, the app sends the patient's Glucose, Haemoglobin,
   and Cholesterol values to that external API and uses its response as the
   Remarks.
2. Otherwise (default), a local `RandomForestClassifier` — trained on
   synthetic data generated from standard clinical reference ranges for
   glucose, haemoglobin, and cholesterol — predicts a risk category
   (Low / Moderate / High Risk), and the app stores the prediction plus a
   short plain-English explanation in the Remarks field.

This dual approach was chosen so the project (a) satisfies the
"AI/ML API integration" requirement using a genuine ML model with
no external dependency or account needed to run/demo it, while (b) remaining
trivially extensible to any real external Health API by just setting two
environment variables — no code changes required.

## Notes on security

No API keys or secrets are committed to this repository. The external API
integration (optional) reads credentials only from environment variables /
a local, git-ignored `.env` file.

## Disclaimer

This application is a technical demonstration only. Predictions are not
medical advice and should not be used for real diagnosis or treatment
decisions.
