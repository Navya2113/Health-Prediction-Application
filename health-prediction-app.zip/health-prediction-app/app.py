"""
app.py
------
Streamlit frontend for the Health Prediction Application.

Run with:
    streamlit run app.py
"""

import streamlit as st
from datetime import date
import pandas as pd

import database as db
from validators import validate_patient_form
from predictor import predict_health_risk

st.set_page_config(page_title="Health Prediction App", page_icon="🩺", layout="wide")
db.init_db()

st.title("🩺 Health Prediction Application")
st.caption(
    "Manage patient blood test records and generate AI-assisted health risk remarks."
)

tab_list, tab_add, tab_edit = st.tabs(["📋 Patient Records", "➕ Add Patient", "✏️ Update / Delete"])

# ---------------------------------------------------------------------------
# TAB 1: LIST / READ
# ---------------------------------------------------------------------------
with tab_list:
    patients = db.get_all_patients()
    if not patients:
        st.info("No patient records yet. Add one from the 'Add Patient' tab.")
    else:
        df = pd.DataFrame(patients)[
            ["id", "full_name", "dob", "email", "glucose", "haemoglobin", "cholesterol", "remarks"]
        ]
        df.columns = ["ID", "Full Name", "DOB", "Email", "Glucose", "Haemoglobin", "Cholesterol", "Remarks"]
        st.dataframe(df, use_container_width=True, hide_index=True)
        st.caption(f"Total records: {len(patients)}")

# ---------------------------------------------------------------------------
# TAB 2: CREATE
# ---------------------------------------------------------------------------
with tab_add:
    st.subheader("Add a new patient record")
    with st.form("add_patient_form", clear_on_submit=True):
        col1, col2 = st.columns(2)
        with col1:
            full_name = st.text_input("Full Name")
            dob = st.date_input("Date of Birth", min_value=date(1900, 1, 1), max_value=date.today())
            email = st.text_input("Email Address")
        with col2:
            glucose = st.number_input("Glucose (mg/dL)", min_value=0.0, max_value=1000.0, step=0.1)
            haemoglobin = st.number_input("Haemoglobin (g/dL)", min_value=0.0, max_value=30.0, step=0.1)
            cholesterol = st.number_input("Cholesterol (mg/dL)", min_value=0.0, max_value=1000.0, step=0.1)

        submitted = st.form_submit_button("Save & Predict")

        if submitted:
            errors = validate_patient_form(full_name, dob, email, glucose, haemoglobin, cholesterol)
            if errors:
                for e in errors:
                    st.error(e)
            else:
                remarks = predict_health_risk(glucose, haemoglobin, cholesterol)
                db.create_patient(
                    full_name.strip(), dob.isoformat(), email.strip(),
                    glucose, haemoglobin, cholesterol, remarks,
                )
                st.success(f"Record saved. AI Remarks: {remarks}")
                st.rerun()

# ---------------------------------------------------------------------------
# TAB 3: UPDATE / DELETE
# ---------------------------------------------------------------------------
with tab_edit:
    st.subheader("Update or delete an existing record")
    patients = db.get_all_patients()
    if not patients:
        st.info("No records available to edit.")
    else:
        options = {f"#{p['id']} - {p['full_name']}": p["id"] for p in patients}
        selected_label = st.selectbox("Select a patient", list(options.keys()))
        selected_id = options[selected_label]
        patient = db.get_patient(selected_id)

        with st.form("edit_patient_form"):
            col1, col2 = st.columns(2)
            with col1:
                full_name = st.text_input("Full Name", value=patient["full_name"])
                dob_value = date.fromisoformat(patient["dob"])
                dob = st.date_input("Date of Birth", value=dob_value, min_value=date(1900, 1, 1), max_value=date.today())
                email = st.text_input("Email Address", value=patient["email"])
            with col2:
                glucose = st.number_input("Glucose (mg/dL)", min_value=0.0, max_value=1000.0, step=0.1, value=float(patient["glucose"]))
                haemoglobin = st.number_input("Haemoglobin (g/dL)", min_value=0.0, max_value=30.0, step=0.1, value=float(patient["haemoglobin"]))
                cholesterol = st.number_input("Cholesterol (mg/dL)", min_value=0.0, max_value=1000.0, step=0.1, value=float(patient["cholesterol"]))

            st.text_area("Current Remarks", value=patient["remarks"], disabled=True)

            col_a, col_b = st.columns(2)
            update_clicked = col_a.form_submit_button("🔄 Update & Re-predict")
            delete_clicked = col_b.form_submit_button("🗑️ Delete Record")

            if update_clicked:
                errors = validate_patient_form(full_name, dob, email, glucose, haemoglobin, cholesterol)
                if errors:
                    for e in errors:
                        st.error(e)
                else:
                    remarks = predict_health_risk(glucose, haemoglobin, cholesterol)
                    db.update_patient(
                        selected_id, full_name.strip(), dob.isoformat(), email.strip(),
                        glucose, haemoglobin, cholesterol, remarks,
                    )
                    st.success(f"Record updated. New AI Remarks: {remarks}")
                    st.rerun()

            if delete_clicked:
                db.delete_patient(selected_id)
                st.warning("Record deleted.")
                st.rerun()

st.divider()
st.caption(
    "Predictions are generated by a local ML model (or an external Health API if configured) "
    "and are for demonstration purposes only — not a substitute for professional medical advice."
)
